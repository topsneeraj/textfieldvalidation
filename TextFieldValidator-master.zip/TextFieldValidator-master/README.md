TextFieldValidator
==================
A lightweight, customizable subclass of UITextField that supports multiple regex validations and provides a simple UI to provide validation feedback.

See the original blog post for details: https://dhawaldawar.wordpress.com/2014/06/11/uitextfield-validation-ios/
